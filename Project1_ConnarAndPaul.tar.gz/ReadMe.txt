To make: type make
To run: type ./quash
